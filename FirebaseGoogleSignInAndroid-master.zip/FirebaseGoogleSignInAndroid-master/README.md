# Firebase Google Sign-In for Android

A demonstration of implementation of authentication with Google in an Android application.

## Tutorial

* [Website](http://alvarez.tech/android-log-in-con-google/)
* [Video](https://www.youtube.com/watch?v=O3aemJ9eAAA)
