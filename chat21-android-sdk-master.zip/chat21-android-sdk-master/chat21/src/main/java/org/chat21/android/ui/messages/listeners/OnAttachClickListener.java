package org.chat21.android.ui.messages.listeners;

import java.io.Serializable;

/**
 * Created by stefanodp91 on 29/03/17.
 */
public interface OnAttachClickListener extends Serializable {
    void onAttachClicked(Object object);
}
