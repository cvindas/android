package org.chat21.android.ui.conversations.listeners;

import java.io.Serializable;

/**
 * Created by stefanodp91 on 29/03/17.
 */
public interface OnNewConversationClickListener extends Serializable {
    void onNewConversationClicked();
}
