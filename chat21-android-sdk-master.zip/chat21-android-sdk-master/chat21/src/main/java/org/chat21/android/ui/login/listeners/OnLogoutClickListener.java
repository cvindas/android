package org.chat21.android.ui.login.listeners;

/**
 * Created by stefanodp91 on 07/12/17.
 */

public interface OnLogoutClickListener {
    void onLogoutClicked();
}
