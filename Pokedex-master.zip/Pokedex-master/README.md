# Pokedex

An application that uses Retrofit to consume the Pokeapi API, in addition to loading images with Glide.

## Step-by-step tutorial and video

[alvarez.tech/labs/android-retrofit-pokedex](https://alvarez.tech/labs/android-retrofit-pokedex)

## Screenshots

<img width="300" alt="Pokedex" src="https://cloud.githubusercontent.com/assets/1444991/26534839/21df4744-43f6-11e7-82df-609a2163d050.png">
<img width="300" alt="Pokedex" src="https://cloud.githubusercontent.com/assets/1444991/26534840/21e08136-43f6-11e7-910d-a17f3c9242ba.png">
<img width="300" alt="Pokedex" src="https://cloud.githubusercontent.com/assets/1444991/26534838/21d96cde-43f6-11e7-8667-08433c4a126f.png">
